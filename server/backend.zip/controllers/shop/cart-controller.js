const Cart = require("../../models/Cart");
const Product = require("../../models/Product");

const addToCart = async (req, res) => {
  try {
    const { userId, productId, quantity, color } = req.body;
    console.log("Add to cart request:", { userId, productId, quantity, color });

    if (!userId || !productId || quantity <= 0) {
      console.log("Invalid data provided:", { userId, productId, quantity });
      return res.status(400).json({
        success: false,
        message: "Invalid data provided!",
      });
    }

    const product = await Product.findById(productId);

    if (!product) {
      console.log("Product not found:", productId);
      return res.status(404).json({
        success: false,
        message: "Product not found",
      });
    }

    const normalizedColor = color?.trim() || "";
    const hasColorOptions = Array.isArray(product.colors) && product.colors.length > 0;

    if (hasColorOptions && !normalizedColor) {
      return res.status(400).json({
        success: false,
        message: "Please select a color before adding to cart.",
      });
    }

    let cart = await Cart.findOne({ userId });
    console.log("Existing cart:", cart);

    if (!cart) {
      cart = new Cart({ userId, items: [] });
      console.log("Created new cart for user:", userId);
    }

    const findCurrentProductIndex = cart.items.findIndex(
      (item) =>
        item.productId.toString() === productId &&
        (item.color || "") === normalizedColor,
    );

    if (findCurrentProductIndex === -1) {
      cart.items.push({ productId, quantity, color: normalizedColor });
      console.log("Added new item to cart");
    } else {
      cart.items[findCurrentProductIndex].quantity += quantity;
      cart.items[findCurrentProductIndex].color = normalizedColor;
      console.log("Updated existing item quantity");
    }

    await cart.save();
    console.log("Cart saved successfully:", cart);

    res.status(200).json({
      success: true,
      data: cart,
    });
  } catch (error) {
    console.log("Cart error:", error);
    res.status(500).json({
      success: false,
      message: "Error",
    });
  }
};

const fetchCartItems = async (req, res) => {
  try {
    const { userId } = req.params;

    if (!userId) {
      return res.status(400).json({
        success: false,
        message: "User id is manadatory!",
      });
    }

    const cart = await Cart.findOne({ userId }).populate({
      path: "items.productId",
      select: "image title price salePrice size",
    });

    if (!cart) {
      // For guests or new users, return an empty cart instead of 404
      return res.status(200).json({
        success: true,
        data: { _id: null, userId, items: [] },
      });
    }

    const validItems = cart.items.filter(
      (productItem) => productItem.productId,
    );

    if (validItems.length < cart.items.length) {
      cart.items = validItems;
      await cart.save();
    }

    const populateCartItems = validItems.map((item) => ({
      productId: item.productId._id,
      image: item.productId.image,
      title: item.productId.title,
      price: item.productId.price,
      salePrice: item.productId.salePrice,
      size: item.productId.size || "",
      color: item.color || "",
      quantity: item.quantity,
    }));

    res.status(200).json({
      success: true,
      data: {
        ...cart._doc,
        items: populateCartItems,
      },
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({
      success: false,
      message: "Error",
    });
  }
};

const updateCartItemQty = async (req, res) => {
  try {
    const { userId, productId, quantity } = req.body;

    if (!userId || !productId || quantity <= 0) {
      return res.status(400).json({
        success: false,
        message: "Invalid data provided!",
      });
    }

    const cart = await Cart.findOne({ userId });
    if (!cart) {
      return res.status(404).json({
        success: false,
        message: "Cart not found!",
      });
    }

    const findCurrentProductIndex = cart.items.findIndex(
      (item) => item.productId.toString() === productId,
    );

    if (findCurrentProductIndex === -1) {
      return res.status(404).json({
        success: false,
        message: "Cart item not present !",
      });
    }

    cart.items[findCurrentProductIndex].quantity = quantity;
    await cart.save();

    await cart.populate({
      path: "items.productId",
      select: "image title price salePrice size",
    });

    const populateCartItems = cart.items.map((item) => ({
      productId: item.productId ? item.productId._id : null,
      image: item.productId ? item.productId.image : null,
      title: item.productId ? item.productId.title : "Product not found",
      price: item.productId ? item.productId.price : null,
      salePrice: item.productId ? item.productId.salePrice : null,
      size: item.productId ? item.productId.size || "" : "",
      color: item.color || "",
      quantity: item.quantity,
    }));

    res.status(200).json({
      success: true,
      data: {
        ...cart._doc,
        items: populateCartItems,
      },
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({
      success: false,
      message: "Error",
    });
  }
};

const deleteCartItem = async (req, res) => {
  try {
    const { userId, productId } = req.params;
    if (!userId || !productId) {
      return res.status(400).json({
        success: false,
        message: "Invalid data provided!",
      });
    }

    const cart = await Cart.findOne({ userId }).populate({
      path: "items.productId",
      select: "image title price salePrice size",
    });

    if (!cart) {
      return res.status(404).json({
        success: false,
        message: "Cart not found!",
      });
    }

    cart.items = cart.items.filter(
      (item) => item.productId._id.toString() !== productId,
    );

    await cart.save();

    await cart.populate({
      path: "items.productId",
      select: "image title price salePrice size",
    });

    const populateCartItems = cart.items.map((item) => ({
      productId: item.productId ? item.productId._id : null,
      image: item.productId ? item.productId.image : null,
      title: item.productId ? item.productId.title : "Product not found",
      price: item.productId ? item.productId.price : null,
      salePrice: item.productId ? item.productId.salePrice : null,
      size: item.productId ? item.productId.size || "" : "",
      color: item.color || "",
      quantity: item.quantity,
    }));

    res.status(200).json({
      success: true,
      data: {
        ...cart._doc,
        items: populateCartItems,
      },
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({
      success: false,
      message: "Error",
    });
  }
};

module.exports = {
  addToCart,
  updateCartItemQty,
  deleteCartItem,
  fetchCartItems,
};
